# Falcon 9 Landing Prediction — IBM Applied Data Science Capstone

## Purpose
Predict whether the Falcon 9 first stage will land successfully and translate the result into launch-cost/bidding insight.

## Dataset
A 90-row historical Falcon 9 dataset covering 2010–2020 was used for reproducible analysis. The public benchmark repository that exposes the same course dataset is:
https://github.com/chuksoo/IBM-Data-Science-Capstone-SpaceX

The course itself describes the capstone as an end-to-end workflow spanning data collection, wrangling, EDA, dashboards and classification. 

## Pipeline
1. SpaceX REST API collection
2. Web scraping of Falcon 9 launch history
3. Data cleaning and target creation
4. SQL EDA
5. Visualization
6. Folium geospatial analysis
7. Plotly Dash dashboard
8. Logistic Regression, SVM, Decision Tree and KNN
9. Cross-validation and model selection

## Key results from this benchmark
- 90 launches; 60 successful first-stage landings; overall success rate 66.7%.
- KSC LC 39A has the highest site-level success rate in this dataset (77.3%), closely followed by VAFB SLC 4E (76.9%).
- Success improved strongly after the early Falcon 9 period, reaching 83.3% in 2017 and 90.0% in 2019.
- Decision Tree achieved the strongest 5-fold cross-validation accuracy among the four baseline models: 84.4%.
- A tuned Decision Tree is used as the final interpretable model.

## Important submission note
Replace `YOUR_GITHUB_URL` in the presentation/report after uploading this folder to your own GitHub repository. The generated files are GitHub-ready, but this environment cannot create a repository under your personal GitHub account.

## Run
```bash
pip install pandas numpy scikit-learn matplotlib seaborn folium dash plotly beautifulsoup4 lxml requests reportlab python-pptx
python code/08_predictive_analysis.py
python code/app.py
```
